<?php
namespace App\Http\Controllers\Front;
use App\Http\Controllers\Controller;
use Redirect;
use DB;

class PayPalController extends Controller
{
  
}
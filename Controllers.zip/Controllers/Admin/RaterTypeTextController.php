<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RaterTypes;
use App\Models\RaterTypesText;
use App\Models\Languages;

class RaterTypeTextController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index($id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');
    	$data['page_title'] = "Rater Type Text";
    	$data['RaterTypes'] = RaterTypes::find($id);
    	$data['id'] = $id;
    	$data['RaterTypesTexts'] = RaterTypesText::where('rater_id',$id)->get();
    	return view('admin.rater_type_text.manage',$data);
    }

    public function create(Request $request, $id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');

    	$data['page_title'] = "Create Rater Type Text";
    	$data['languages'] = Languages::where('status','Y')->get();
    	$data['RaterTypes'] = RaterTypes::find($id);

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['rater_id'=>'required', 'other_name'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $RaterTypesText = new RaterTypesText();
    	    $RaterTypesText->rater_id 		= $inputs['rater_id'];
    	    $RaterTypesText->other_name 	= $inputs['other_name'];
    	    $RaterTypesText->language_id 	= $inputs['language_id'];
			$RaterTypesText->status 		= $inputs['status'];
			$RaterTypesText->created_at		= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($RaterTypesText); die;
    	    if(!$RaterTypesText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.raters_type_text',$id)->with('success', 'Rater Type Text Added Successfully.'); 
    	}
    	return view('admin.rater_type_text.create',$data);
    }

    public function update(Request $request, $id=null, $text_id=null){
        if(is_null($id) && is_null($text_id))
            return back()->with('danger','Something went wrong, Please try again.');
        
        $RaterTypes = RaterTypes::find($id);
        $RaterTypesText = RaterTypesText::where(['id' => $text_id, 'rater_id' => $id])->first();
        if(@$RaterTypes->id == "" || @$RaterTypesText->id == "")
            return back()->with('danger','Rater Type Text not found, Please try again.');

    	$data['page_title'] = "Edit Rater Type Text";
        $data['languages'] = Languages::where('status','Y')->get();
    	$data['RaterTypes'] = $RaterTypes;
    	$data['form_data'] = $RaterTypesText;

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['rater_id'=>'required', 'other_name'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $RaterTypesText->rater_id 		= $inputs['rater_id'];
    	    $RaterTypesText->other_name 	= $inputs['other_name'];
    	    $RaterTypesText->language_id 	= $inputs['language_id'];
			$RaterTypesText->status 		= $inputs['status'];
			$RaterTypesText->updated_at				= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($RaterTypesText); die;
    	    if(!$RaterTypesText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.raters_type_text',$id)->with('success', 'Rater Type Text Updated Successfully.'); 
    	}
    	return view('admin.rater_type_text.create',$data);
    }

    public function remove(Request $request, $id=null, $text_id=null){
    	if(is_null($id) && is_null($text_id))
    	    return back()->with('danger','Something went wrong, Please try again.');

        $RaterTypesText = RaterTypesText::where(['id' => $text_id, 'rater_id' => $id])->first();
        if(@$RaterTypesText->id == "")
            return back()->with('danger','Invitation text not found, Please try again.');

        $data['page_title'] = "Delete Invitation Text";
        if(!$RaterTypesText->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.raters_type_text',$id)->with('success', 'Invitation Text Deleted Successfully.'); 
    }
}
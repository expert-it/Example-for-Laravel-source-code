<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ParticipantsReminderInvite;
use App\Models\ParticipantsReminderInviteText;
use App\Models\Languages;

class ParticipantsReminderInviteTextController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index($id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');
    	$data['page_title'] = "Reminder Invitation Text";
    	$data['ParticipantsReminderInvite'] = ParticipantsReminderInvite::find($id);
    	$data['id'] = $id;
    	$data['ParticipantsInviteTexts'] = ParticipantsReminderInviteText::where('reminder_id',$id)->get();
    	return view('admin.participants_reminder_invite_text.manage',$data);
    }

    private function getParticipantsInviteTextSortCount(){
    	$count = 1;
    	$ParticipantsInvite = ParticipantsReminderInviteText::orderBy('sort','DESC')->first();
    	if(@$ParticipantsInvite->id)
    		$count = ++$ParticipantsInvite->sort;
    	return $count;
    }

    public function create(Request $request, $id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');

    	$data['page_title'] = "Create Reminder Invitation Text";
    	$data['languages'] = Languages::where('status','Y')->get();
    	$data['ParticipantsInvite'] = ParticipantsReminderInvite::find($id);

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['reminder_id'=>'required', 'reminder_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $ParticipantsInviteText = new ParticipantsReminderInviteText();
    	    $ParticipantsInviteText->reminder_id	= $inputs['reminder_id'];
    	    $ParticipantsInviteText->reminder_text	= $inputs['reminder_text'];
    	    $ParticipantsInviteText->language_id 	= $inputs['language_id'];
			$ParticipantsInviteText->status 		= $inputs['status'];
			$ParticipantsInviteText->sort 			= $this->getParticipantsInviteTextSortCount();
			$ParticipantsInviteText->created_at		= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($ParticipantsInviteText); die;
    	    if(!$ParticipantsInviteText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.participants_reminder_invite_text',$id)->with('success', 'Reminder Invitation Text Added Successfully.'); 
    	}
    	return view('admin.participants_reminder_invite_text.create',$data);
    }

    public function update(Request $request, $id=null, $text_id=null){
        if(is_null($id) && is_null($text_id))
            return back()->with('danger','Something went wrong, Please try again.');
        
        $ParticipantsInvite = ParticipantsReminderInvite::find($id);
        $ParticipantsInviteText = ParticipantsReminderInviteText::where(['id' => $text_id, 'reminder_id' => $id])->first();
        if(@$ParticipantsInvite->id == "" || @$ParticipantsInviteText->id == "")
            return back()->with('danger','Reminder Invitation text not found, Please try again.');

    	$data['page_title'] = "Edit Reminder Invitation Text";
        $data['languages'] = Languages::where('status','Y')->get();
    	$data['ParticipantsInvite'] = $ParticipantsInvite;
    	$data['form_data'] = $ParticipantsInviteText;

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['reminder_id'=>'required', 'reminder_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
            $ParticipantsInviteText->reminder_id    = $inputs['reminder_id'];
            $ParticipantsInviteText->reminder_text  = $inputs['reminder_text'];
            $ParticipantsInviteText->language_id    = $inputs['language_id'];
            $ParticipantsInviteText->status         = $inputs['status'];
			$ParticipantsInviteText->updated_at				= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($ParticipantsInviteText); die;
    	    if(!$ParticipantsInviteText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.participants_reminder_invite_text',$id)->with('success', 'Reminder Invitation Text Updated Successfully.'); 
    	}
    	return view('admin.participants_reminder_invite_text.create',$data);
    }

    public function remove(Request $request, $id=null, $text_id=null){
    	if(is_null($id) && is_null($text_id))
    	    return back()->with('danger','Something went wrong, Please try again.');

        $ParticipantsInviteText = ParticipantsReminderInviteText::where(['id' => $text_id, 'reminder_id' => $id])->first();
        if(@$ParticipantsInviteText->id == "")
            return back()->with('danger','Reminder Invitation text not found, Please try again.');

        $data['page_title'] = "Delete Reminder Invitation Text";
        if(!$ParticipantsInviteText->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.participants_reminder_invite_text',$id)->with('success', 'Reminder Invitation Text Deleted Successfully.'); 
    }
}
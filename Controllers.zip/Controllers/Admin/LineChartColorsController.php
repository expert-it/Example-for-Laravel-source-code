<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LineChartColors;

class LineChartColorsController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	$data['page_title'] = "Chart Colors";
    	$data['colors'] = LineChartColors::get();
    	return view('admin.line_chart_colors.manage',$data);
    }

    public function update(Request $request){
    	$data['page_title'] = "Update Chart Colors";
        $inputs = $request->all();
        if(@count($inputs) > 0){
    		try {
	    		if(count($inputs['id']) > 0){
	    			foreach ($inputs['id'] as $key => $id) {
	    				$model = LineChartColors::find($id);
	    				$model->rcolor = $inputs['rcolor'][$key];
			    		$model->gcolor = $inputs['gcolor'][$key];
			    		$model->bcolor = $inputs['bcolor'][$key];
			    		$model->updated_at = date("Y-m-d H:i:s");
			    		$model->save();
	    			}
	    		}	
	    		return redirect()->route('admin.line_chart_color')->with('success', 'Chart Colors Updated Successfully.'); 
    		} catch (Exception $e) {
    			return redirect()->route('admin.line_chart_color')->with('danger','Something went wrong, Please try again.');	
    		}    
        }
        return redirect()->route('admin.line_chart_color')->with('danger','Something went wrong, Please try again.');
    }

}


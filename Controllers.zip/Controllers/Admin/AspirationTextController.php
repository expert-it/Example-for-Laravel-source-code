<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AspirationQuestion;
use App\Models\AspirationText;
use App\Models\Languages;

class AspirationTextController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index($id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');
    	$data['page_title'] = "Aspiration Text";
    	$data['aspirationQuestion'] = AspirationQuestion::find($id);
    	$data['id'] = $id;
    	$data['aspirationTexts'] = AspirationText::where('aspiration_question_id',$id)->get();
    	return view('admin.aspiration_text.manage',$data);
    }

    private function getAspirationTextSortCount(){
    	$count = 1;
    	$AspirationQuestion = AspirationText::orderBy('sort','DESC')->first();
    	if(@$AspirationQuestion->id)
    		$count = ++$AspirationQuestion->sort;
    	return $count;
    }

    public function create(Request $request, $id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');

    	$data['page_title'] = "Create Aspiration Text";
    	$data['languages'] = Languages::where('status','Y')->get();
    	$data['aspirationQuestion'] = AspirationQuestion::find($id);

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['aspiration_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $AspirationText = new AspirationText();
    	    $AspirationText->aspiration_question_id	= $id;
    	    $AspirationText->language_id			= $inputs['language_id'];
    	    $AspirationText->aspiration_text 		= $inputs['aspiration_text'];
			$AspirationText->status 				= $inputs['status'];
			$AspirationText->sort 					= $this->getAspirationTextSortCount();
			$AspirationText->created_at				= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($AspirationText); die;
    	    if(!$AspirationText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.aspiration_text',$id)->with('success', 'Aspiration Text Added Successfully.'); 
    	}
    	return view('admin.aspiration_text.create',$data);
    }

    public function update(Request $request, $id=null, $text_id=null){
        if(is_null($id) && is_null($text_id))
            return back()->with('danger','Something went wrong, Please try again.');
        
        $AspirationQuestion = AspirationQuestion::find($id);
        $AspirationText = AspirationText::where(['id' => $text_id, 'aspiration_question_id' => $id])->first();
        if(@$AspirationQuestion->id == "" || @$AspirationText->id == "")
            return back()->with('danger','Aspiration text not found, Please try again.');

    	$data['page_title'] = "Edit Aspiration Text";
        $data['languages'] = Languages::where('status','Y')->get();
    	$data['aspirationQuestion'] = $AspirationQuestion;
    	$data['form_data'] = $AspirationText;

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['aspiration_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $AspirationText->aspiration_question_id	= $id;
    	    $AspirationText->language_id			= $inputs['language_id'];
    	    $AspirationText->aspiration_text 		= $inputs['aspiration_text'];
			$AspirationText->status 				= $inputs['status'];
			$AspirationText->created_at				= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($AspirationText); die;
    	    if(!$AspirationText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.aspiration_text',$id)->with('success', 'Aspiration Text Updated Successfully.'); 
    	}
    	return view('admin.aspiration_text.create',$data);
    }

    public function remove(Request $request, $id=null, $text_id=null){
    	if(is_null($id) && is_null($text_id))
    	    return back()->with('danger','Something went wrong, Please try again.');

        $AspirationText = AspirationText::where(['id' => $text_id, 'aspiration_question_id' => $id])->first();
        if(@$AspirationText->id == "")
            return back()->with('danger','Aspiration text not found, Please try again.');

        $data['page_title'] = "Delete Aspiration Text";
        if(!$AspirationText->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.aspiration_text',$id)->with('success', 'Aspiration Text Deleted Successfully.'); 
    }
}
<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RaterTypes;

class RaterTypesController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	$data['page_title'] = "Rater Types";
    	$data['raterTypes'] = RaterTypes::get();
    	return view('admin.rater_type.manage',$data);
    }

    private function getAspirationSortCount(){
    	$count = 1;
    	$RaterTypes = RaterTypes::orderBy('sort','DESC')->first();
    	if(@$RaterTypes->id)
    		$count = ++$RaterTypes->sort;
    	return $count;
    }

    public function create(Request $request){
    	$data['page_title'] = "Create Rater Type";
    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['rater_type'=>'required', 'status'=>'required']);
    	    $RaterTypes = new RaterTypes();
			$RaterTypes->rater_type = $inputs['rater_type'];
			$RaterTypes->status 	= $inputs['status'];
			$RaterTypes->sort 		= $this->getAspirationSortCount();
			$RaterTypes->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($RaterTypes); die;
    	    if(!$RaterTypes->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.raters_type')->with('success', 'Rater Type Added Successfully.'); 
    	}
    	return view('admin.rater_type.create',$data);
    }

    public function update(Request $request, $id=null){
        if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $RaterTypes = RaterTypes::find($id);
        if(@$RaterTypes->id == "")
            return back()->with('danger','Rater Type not found, Please try again.');

    	$data['page_title'] = "Edit Rater Type";
        $data['form_data'] = $RaterTypes;

        $inputs = $request->all();
        if(@count($inputs) > 0){
            $this->validate($request,['rater_type'=>'required', 'status'=>'required']);
            $RaterTypes->rater_type = $inputs['rater_type'];
            $RaterTypes->status     = $inputs['status'];
            $RaterTypes->updated_at = date("Y-m-d H:i:s");
            // echo "<pre>"; print_r($RaterTypes); die;
            if(!$RaterTypes->save())
                return back()->with('danger','Something went wrong, Please try again.');
            else
                return redirect()->route('admin.raters_type')->with('success', 'Rater Type Updated Successfully.'); 
        }
        return view('admin.rater_type.create',$data);
    }

    public function remove(Request $request, $id=null){
    	if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $RaterTypes = RaterTypes::find($id);
        if(@$RaterTypes->id == "")
            return back()->with('danger','Rater Type not found, Please try again.');

        $data['page_title'] = "Delete Rater Type";
        if(!$RaterTypes->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.raters_type')->with('success', 'Rater Type Deleted Successfully.'); 
        
    }
}

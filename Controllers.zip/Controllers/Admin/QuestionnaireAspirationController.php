<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Languages;
use App\Models\AspirationQuestion;
use App\Models\Questionnaire;
use App\Models\QuestionnaireAspiration;

class QuestionnaireAspirationController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index($id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');
    	$data['page_title'] = "Questionnaire Aspiration";
    	$data['Questionnaire'] = Questionnaire::find($id);
    	$data['id'] = $id;
    	$data['QuestionnaireAspirations'] = QuestionnaireAspiration::where('questionnaire_id',$id)->get();
    	return view('admin.questionnaire_aspiration.manage',$data);
    }

    private function getQuestionnaireAspirationSortCount(){
    	$count = 1;
    	$AspirationQuestion = QuestionnaireAspiration::orderBy('sort','DESC')->first();
    	if(@$AspirationQuestion->id)
    		$count = ++$AspirationQuestion->sort;
    	return $count;
    }

    public function create(Request $request, $id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');

    	$data['page_title'] = "Create Questionnaire Aspiration";
    	$data['Questionnaire'] = Questionnaire::find($id);
    	$data['AspirationQuestions'] = AspirationQuestion::where('status','Y')->get();

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['questionnaire_id'=>'required', 'aspiration_id'=>'required', 'status'=>'required']);
    	    $QuestionnaireAspiration = new QuestionnaireAspiration();
    	    $QuestionnaireAspiration->questionnaire_id	= $inputs['questionnaire_id'];
    	    $QuestionnaireAspiration->aspiration_id	= $inputs['aspiration_id'];
			$QuestionnaireAspiration->status 		= $inputs['status'];
			$QuestionnaireAspiration->sort 			= $this->getQuestionnaireAspirationSortCount();
			$QuestionnaireAspiration->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($QuestionnaireAspiration); die;
    	    if(!$QuestionnaireAspiration->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.questionnaire_aspiration',$id)->with('success', 'Questionnaire Aspiration Added Successfully.'); 
    	}
    	return view('admin.questionnaire_aspiration.create',$data);
    }

    public function update(Request $request, $id=null, $text_id=null){
        if(is_null($id) && is_null($text_id))
            return back()->with('danger','Something went wrong, Please try again.');
        
        $Questionnaire = Questionnaire::find($id);
        $QuestionnaireAspiration = QuestionnaireAspiration::where(['id' => $text_id, 'questionnaire_id' => $id])->first();
        if(@$Questionnaire->id == "" || @$QuestionnaireAspiration->id == "")
            return back()->with('danger','Schor Questionnaire Aspiration not found, Please try again.');

        $data['AspirationQuestions'] = AspirationQuestion::where('status','Y')->get();
    	$data['page_title'] = "Edit Questionnaire Aspiration";
    	$data['Questionnaire'] = $Questionnaire;
    	$data['form_data'] = $QuestionnaireAspiration;

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['questionnaire_id'=>'required', 'aspiration_id'=>'required', 'status'=>'required']);
    	    $QuestionnaireAspiration->questionnaire_id	= $inputs['questionnaire_id'];
    	    $QuestionnaireAspiration->aspiration_id	= $inputs['aspiration_id'];
			$QuestionnaireAspiration->status 		= $inputs['status'];
			$QuestionnaireAspiration->updated_at			= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($QuestionnaireAspiration); die;
    	    if(!$QuestionnaireAspiration->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.questionnaire_aspiration',$id)->with('success', 'Questionnaire Aspiration Updated Successfully.'); 
    	}
    	return view('admin.questionnaire_aspiration.create',$data);
    }

    public function remove(Request $request, $id=null, $text_id=null){
    	if(is_null($id) && is_null($text_id))
    	    return back()->with('danger','Something went wrong, Please try again.');

        $QuestionnaireAspiration = QuestionnaireAspiration::where(['id' => $text_id, 'questionnaire_id' => $id])->first();
        if(@$QuestionnaireAspiration->id == "")
            return back()->with('danger','Questionnaire Aspiration text not found, Please try again.');

        $data['page_title'] = "Delete Questionnaire Aspiration";
        if(!$QuestionnaireAspiration->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.questionnaire_aspiration',$id)->with('success', 'Questionnaire Aspiration Deleted Successfully.'); 
    }
}

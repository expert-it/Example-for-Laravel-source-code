<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ParticipantsReminderInvite;

class ParticipantsReminderInviteController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	$data['page_title'] = "Reminder Participant Invite";
    	$data['ParticipantsReminderInvites'] = ParticipantsReminderInvite::get();
    	return view('admin.participants_reminder_invite.manage',$data);
    }

    private function getParticipantsReminderInviteCount(){
    	$count = 1;
    	$ParticipantsReminderInvite = ParticipantsReminderInvite::orderBy('sort','DESC')->first();
    	if(@$ParticipantsReminderInvite->id)
    		$count = ++$ParticipantsReminderInvite->sort;
    	return $count;
    }

    public function create(Request $request){
    	$data['page_title'] = "Create Reminder Participant Invite";
    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['reminder_name'=>'required', 'status'=>'required']);
    	    $ParticipantsReminderInvite = new ParticipantsReminderInvite();
			$ParticipantsReminderInvite->reminder_name = $inputs['reminder_name'];
			$ParticipantsReminderInvite->status 	= $inputs['status'];
			$ParticipantsReminderInvite->sort 		= $this->getParticipantsReminderInviteCount();
			$ParticipantsReminderInvite->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($ParticipantsReminderInvite); die;
    	    if(!$ParticipantsReminderInvite->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.participants_reminder_invite')->with('success', 'Reminder Participant Invite Added Successfully.'); 
    	}
    	return view('admin.participants_reminder_invite.create',$data);
    }

    public function update(Request $request, $id=null){
        if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $ParticipantsReminderInvite = ParticipantsReminderInvite::find($id);
        if(@$ParticipantsReminderInvite->id == "")
            return back()->with('danger','Participant Invite not found, Please try again.');

    	$data['page_title'] = "Edit Participant Invite Participant Invite";
        $data['form_data'] = $ParticipantsReminderInvite;

        $inputs = $request->all();
        if(@count($inputs) > 0){
    		$this->validate($request,['reminder_name'=>'required', 'status'=>'required']);
			$ParticipantsReminderInvite->reminder_name = $inputs['reminder_name'];
            $ParticipantsReminderInvite->status     = $inputs['status'];
            $ParticipantsReminderInvite->updated_at = date("Y-m-d H:i:s");
            // echo "<pre>"; print_r($ParticipantsReminderInvite); die;
            if(!$ParticipantsReminderInvite->save())
                return back()->with('danger','Something went wrong, Please try again.');
            else
                return redirect()->route('admin.participants_reminder_invite')->with('success', 'Participant Invite Updated Successfully.'); 
        }
        return view('admin.participants_reminder_invite.create',$data);
    }

    public function remove(Request $request, $id=null){
    	if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $ParticipantsReminderInvite = ParticipantsReminderInvite::find($id);
        if(@$ParticipantsReminderInvite->id == "")
            return back()->with('danger','Participant Invite not found, Please try again.');

        $data['page_title'] = "Delete Participant Invite";
        if(!$ParticipantsReminderInvite->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.participants_reminder_invite')->with('success', 'Participant Invite Deleted Successfully.'); 
        
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AspirationQuestion;

class AspirationsController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	$data['page_title'] = "Aspirations";
    	$data['aspirationQuestions'] = AspirationQuestion::get();
    	return view('admin.aspirations.manage',$data);
    }

    private function getAspirationSortCount(){
    	$count = 1;
    	$AspirationQuestion = AspirationQuestion::orderBy('sort','DESC')->first();
    	if(@$AspirationQuestion->id)
    		$count = ++$AspirationQuestion->sort;
    	return $count;
    }

    public function create(Request $request){
    	$data['page_title'] = "Create Aspirations";
    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['concept'=>'required', 'question_type'=>'required', 'status'=>'required']);
    	    $AspirationQuestion = new AspirationQuestion();
			$AspirationQuestion->concept = $inputs['concept'];
			$AspirationQuestion->question_type 	= $inputs['question_type'];
			$AspirationQuestion->status 	= $inputs['status'];
			$AspirationQuestion->sort 		= $this->getAspirationSortCount();
			$AspirationQuestion->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($AspirationQuestion); die;
    	    if(!$AspirationQuestion->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.aspirations')->with('success', 'Aspiration Added Successfully.'); 
    	}
    	return view('admin.aspirations.create',$data);
    }

    public function update(Request $request, $id=null){
        if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $AspirationQuestion = AspirationQuestion::find($id);
        if(@$AspirationQuestion->id == "")
            return back()->with('danger','Aspirations not found, Please try again.');

    	$data['page_title'] = "Edit Aspirations";
        $data['form_data'] = $AspirationQuestion;

        $inputs = $request->all();
        if(@count($inputs) > 0){
            $this->validate($request,['concept'=>'required', 'question_type'=>'required', 'status'=>'required']);
            $AspirationQuestion->concept = $inputs['concept'];
            $AspirationQuestion->question_type  = $inputs['question_type'];
            $AspirationQuestion->status     = $inputs['status'];
            $AspirationQuestion->updated_at = date("Y-m-d H:i:s");
            // echo "<pre>"; print_r($AspirationQuestion); die;
            if(!$AspirationQuestion->save())
                return back()->with('danger','Something went wrong, Please try again.');
            else
                return redirect()->route('admin.aspirations')->with('success', 'Aspiration Updated Successfully.'); 
        }
        return view('admin.aspirations.create',$data);
    }

    public function remove(Request $request, $id=null){
    	if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $AspirationQuestion = AspirationQuestion::find($id);
        if(@$AspirationQuestion->id == "")
            return back()->with('danger','Aspirations not found, Please try again.');

        $data['page_title'] = "Delete Aspirations";
        if(!$AspirationQuestion->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.aspirations')->with('success', 'Aspiration Deleted Successfully.'); 
        
    }
}

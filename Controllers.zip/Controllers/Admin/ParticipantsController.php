<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\Batch;
use App\Models\Languages;
use App\Models\Participants;
use App\Models\RatersInvite;
use App\Models\Questionnaire;
use App\Models\ParticipantsInvite;
use App\Models\ParticipantsReminderInvite;
use App\Http\Controllers\Utility\CommonController;

class ParticipantsController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index($id=null){
    	if(is_null($id))
    	    return back()->with('danger','Batch not found, Please try again.');
    	$data['page_title'] = "Batch Paticipant";
    	$data['id'] = $id;
    	$data['batch'] = Batch::find($id);
    	$data['participants'] = Participants::where('batch_id',$id)->get();
    	return view('admin.batch_participants.manage',$data);
    }

    public function create(Request $request, $id=null){
    	if(is_null($id))
    	    return back()->with('danger','Batch not found, Please try again.');

    	$data['page_title'] = "Create Batch Paticipant";
    	$data['batch'] = Batch::find($id);
    	$data['languages'] = Languages::where('status','Y')->get();

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['batch_id'=>'required', 'first_name'=>'required', 'last_name'=>'required', 'phone_number'=>'required', 'organization_code'=>'required', 'email'=>'required', 'password_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $Participants = new Participants();
    	    
    	    $Participants->batch_id			= $inputs['batch_id'];
    	    $Participants->first_name		= $inputs['first_name'];
    	    $Participants->last_name 		= $inputs['last_name'];
    	    $Participants->phone_number 	= $inputs['phone_number'];
    	    $Participants->organization_code= $inputs['organization_code'];
    	    $Participants->email 			= $inputs['email'];
            $Participants->username         = CommonController::random_generator(10);
    	    $Participants->password_text 	= $inputs['password_text'];
    	    $Participants->password 		= Hash::make($inputs['password_text']);
    	    $Participants->language_id 		= $inputs['language_id'];
			$Participants->status 			= $inputs['status'];
			$Participants->created_at		= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($Participants); die;
    	    if(!$Participants->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.batch_participants',$id)->with('success', 'Batch Paticipant Added Successfully.'); 
    	}
    	return view('admin.batch_participants.create',$data);
    }

    public function update(Request $request, $id=null, $text_id=null){
        if(is_null($id) && is_null($text_id))
            return back()->with('danger','Something went wrong, Please try again.');
        
        $Batch = Batch::find($id);
        $Participants = Participants::where(['id' => $text_id, 'batch_id' => $id])->first();
        if(@$Batch->id == "" || @$Participants->id == "")
            return back()->with('danger','Batch not found, Please try again.');

    	$data['page_title'] = "Edit Batch Paticipant";
        $data['languages'] = Languages::where('status','Y')->get();
    	$data['batch'] = $Batch;
    	$data['form_data'] = $Participants;

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['batch_id'=>'required', 'first_name'=>'required', 'last_name'=>'required', 'phone_number'=>'required', 'organization_code'=>'required', 'email'=>'required', 'password_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $Participants->batch_id			= $inputs['batch_id'];
    	    $Participants->first_name		= $inputs['first_name'];
    	    $Participants->last_name 		= $inputs['last_name'];
    	    $Participants->phone_number 	= $inputs['phone_number'];
    	    $Participants->organization_code= $inputs['organization_code'];
    	    $Participants->email 			= $inputs['email'];
    	    $Participants->password_text 	= $inputs['password_text'];
    	    $Participants->password 		= Hash::make($inputs['password_text']);
    	    $Participants->language_id 		= $inputs['language_id'];
			$Participants->status 			= $inputs['status'];
			$Participants->created_at				= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($Participants); die;
    	    if(!$Participants->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.batch_participants',$id)->with('success', 'Batch Paticipant Updated Successfully.'); 
    	}
    	return view('admin.batch_participants.create',$data);
    }

    public function remove(Request $request, $id=null, $text_id=null){
    	if(is_null($id) && is_null($text_id))
    	    return back()->with('danger','Something went wrong, Please try again.');

        $AspirationText = Participants::where(['id' => $text_id, 'batch_id' => $id])->first();
        if(@$AspirationText->id == "")
            return back()->with('danger','Participant not found, Please try again.');

        $data['page_title'] = "Delete Participants";
        if(!$AspirationText->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.batch_participants',$id)->with('success', 'Participant Deleted Successfully.'); 
    }
}
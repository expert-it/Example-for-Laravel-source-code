<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RatersInvite;
use App\Models\RatersInviteText;
use App\Models\Languages;

class RatersInviteTextController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index($id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');
    	$data['page_title'] = "Invitation Text";
    	$data['RatersInvite'] = RatersInvite::find($id);
    	$data['id'] = $id;
    	$data['RatersInviteTexts'] = RatersInviteText::where('raters_invite_id',$id)->get();
    	return view('admin.raters_invite_text.manage',$data);
    }

    private function getRatersInviteTextSortCount(){
    	$count = 1;
    	$RatersInvite = RatersInviteText::orderBy('sort','DESC')->first();
    	if(@$RatersInvite->id)
    		$count = ++$RatersInvite->sort;
    	return $count;
    }

    public function create(Request $request, $id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');

    	$data['page_title'] = "Create Invitation Text";
    	$data['languages'] = Languages::where('status','Y')->get();
    	$data['RatersInvite'] = RatersInvite::find($id);

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['raters_invite_id'=>'required', 'raters_invitation_text' => 'required', 'raters_invitation_subject'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $RatersInviteText = new RatersInviteText();
    	    $RatersInviteText->raters_invite_id			= $inputs['raters_invite_id'];
    	    $RatersInviteText->raters_invitation_subject= $inputs['raters_invitation_subject'];
    	    $RatersInviteText->raters_invitation_text 	= $inputs['raters_invitation_text'];
    	    $RatersInviteText->language_id 				= $inputs['language_id'];
			$RatersInviteText->status 					= $inputs['status'];
			$RatersInviteText->sort 					= $this->getRatersInviteTextSortCount();
			$RatersInviteText->created_at				= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($RatersInviteText); die;
    	    if(!$RatersInviteText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.raters_invite_text',$id)->with('success', 'Invitation Text Added Successfully.'); 
    	}
    	return view('admin.raters_invite_text.create',$data);
    }

    public function update(Request $request, $id=null, $text_id=null){
        if(is_null($id) && is_null($text_id))
            return back()->with('danger','Something went wrong, Please try again.');
        
        $RatersInvite = RatersInvite::find($id);
        $RatersInviteText = RatersInviteText::where(['id' => $text_id, 'raters_invite_id' => $id])->first();
        if(@$RatersInvite->id == "" || @$RatersInviteText->id == "")
            return back()->with('danger','Invitation text not found, Please try again.');

    	$data['page_title'] = "Edit Invitation Text";
        $data['languages'] = Languages::where('status','Y')->get();
    	$data['RatersInvite'] = $RatersInvite;
    	$data['form_data'] = $RatersInviteText;

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['raters_invite_id'=>'required', 'raters_invitation_text' => 'required', 'raters_invitation_subject'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $RatersInviteText->raters_invite_id			= $inputs['raters_invite_id'];
    	    $RatersInviteText->raters_invitation_subject= $inputs['raters_invitation_subject'];
    	    $RatersInviteText->raters_invitation_text 	= $inputs['raters_invitation_text'];
    	    $RatersInviteText->language_id 				= $inputs['language_id'];
			$RatersInviteText->status 					= $inputs['status'];
			$RatersInviteText->updated_at				= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($RatersInviteText); die;
    	    if(!$RatersInviteText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.raters_invite_text',$id)->with('success', 'Invitation Text Updated Successfully.'); 
    	}
    	return view('admin.raters_invite_text.create',$data);
    }

    public function remove(Request $request, $id=null, $text_id=null){
    	if(is_null($id) && is_null($text_id))
    	    return back()->with('danger','Something went wrong, Please try again.');

        $RatersInviteText = RatersInviteText::where(['id' => $text_id, 'raters_invite_id' => $id])->first();
        if(@$RatersInviteText->id == "")
            return back()->with('danger','Invitation text not found, Please try again.');

        $data['page_title'] = "Delete Invitation Text";
        if(!$RatersInviteText->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.raters_invite_text',$id)->with('success', 'Invitation Text Deleted Successfully.'); 
    }
}
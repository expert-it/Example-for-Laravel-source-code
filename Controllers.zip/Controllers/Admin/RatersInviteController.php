<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RatersInvite;

class RatersInviteController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	$data['page_title'] = "Raters Invitation";
    	$data['RatersInvites'] = RatersInvite::get();
    	return view('admin.raters_invite.manage',$data);
    }

    private function getRatersInviteCount(){
    	$count = 1;
    	$RatersInvite = RatersInvite::orderBy('sort','DESC')->first();
    	if(@$RatersInvite->id)
    		$count = ++$RatersInvite->sort;
    	return $count;
    }

    public function create(Request $request){
    	$data['page_title'] = "Create Raters Invitation";
    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['raters_invitation'=>'required', 'status'=>'required']);
    	    $RatersInvite = new RatersInvite();
			$RatersInvite->raters_invitation = $inputs['raters_invitation'];
			$RatersInvite->status 	= $inputs['status'];
			$RatersInvite->sort 		= $this->getRatersInviteCount();
			$RatersInvite->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($RatersInvite); die;
    	    if(!$RatersInvite->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.raters_invite')->with('success', 'Raters Invitation Added Successfully.'); 
    	}
    	return view('admin.raters_invite.create',$data);
    }

    public function update(Request $request, $id=null){
        if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $RatersInvite = RatersInvite::find($id);
        if(@$RatersInvite->id == "")
            return back()->with('danger','Raters Invitation not found, Please try again.');

    	$data['page_title'] = "Edit Raters Invitation";
        $data['form_data'] = $RatersInvite;

        $inputs = $request->all();
        if(@count($inputs) > 0){
    		$this->validate($request,['raters_invitation'=>'required', 'status'=>'required']);
			$RatersInvite->raters_invitation = $inputs['raters_invitation'];
			$RatersInvite->status 	= $inputs['status'];
            $RatersInvite->updated_at = date("Y-m-d H:i:s");
            // echo "<pre>"; print_r($RatersInvite); die;
            if(!$RatersInvite->save())
                return back()->with('danger','Something went wrong, Please try again.');
            else
                return redirect()->route('admin.raters_invite')->with('success', 'Raters Invitation Updated Successfully.'); 
        }
        return view('admin.raters_invite.create',$data);
    }

    public function remove(Request $request, $id=null){
    	if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $RatersInvite = RatersInvite::find($id);
        if(@$RatersInvite->id == "")
            return back()->with('danger','Raters Invitation not found, Please try again.');

        $data['page_title'] = "Delete Raters Invitation";
        if(!$RatersInvite->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.raters_invite')->with('success', 'Raters Invitation Deleted Successfully.'); 
        
    }
}

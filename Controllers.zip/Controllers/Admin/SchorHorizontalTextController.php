<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Languages;
use App\Models\SchorHorizontal;
use App\Models\SchorHorizontalText;

class SchorHorizontalTextController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index($id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');
    	$data['page_title'] = "Schor Horizontal Text";
    	$data['schorHorizontal'] = SchorHorizontal::find($id);
    	$data['id'] = $id;
    	$data['schorHorizontalTexts'] = SchorHorizontalText::where('concept_id',$id)->get();
    	return view('admin.schor_horizontal_text.manage',$data);
    }

    private function getSchorHorizontalTextSortCount(){
    	$count = 1;
    	$AspirationQuestion = SchorHorizontalText::orderBy('sort','DESC')->first();
    	if(@$AspirationQuestion->id)
    		$count = ++$AspirationQuestion->sort;
    	return $count;
    }

    public function create(Request $request, $id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');

    	$data['page_title'] = "Create Schor Horizontal Text";
    	$data['languages'] = Languages::where('status','Y')->get();
    	$data['schorHorizontal'] = SchorHorizontal::find($id);

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['schor_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $SchorHorizontalText = new SchorHorizontalText();
    	    $SchorHorizontalText->concept_id	= $id;
    	    $SchorHorizontalText->schor_text	= $inputs['schor_text'];
            $SchorHorizontalText->language_id    = $inputs['language_id'];
			$SchorHorizontalText->status 		= $inputs['status'];
			$SchorHorizontalText->sort 			= $this->getSchorHorizontalTextSortCount();
			$SchorHorizontalText->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($SchorHorizontalText); die;
    	    if(!$SchorHorizontalText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.schor_horizontal_text',$id)->with('success', 'Text Added Successfully.'); 
    	}
    	return view('admin.schor_horizontal_text.create',$data);
    }

    public function update(Request $request, $id=null, $text_id=null){
        if(is_null($id) && is_null($text_id))
            return back()->with('danger','Something went wrong, Please try again.');
        
        $SchorHorizontal = SchorHorizontal::find($id);
        $SchorHorizontalText = SchorHorizontalText::where(['id' => $text_id, 'concept_id' => $id])->first();
        if(@$SchorHorizontal->id == "" || @$SchorHorizontalText->id == "")
            return back()->with('danger','Schor Horizontal Text not found, Please try again.');

    	$data['page_title'] = "Edit Schor Horizontal Text";
        $data['languages'] = Languages::where('status','Y')->get();
    	$data['schorHorizontal'] = $SchorHorizontal;
    	$data['form_data'] = $SchorHorizontalText;

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['schor_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
            $SchorHorizontalText->concept_id    = $inputs['concept_id'];
            $SchorHorizontalText->schor_text    = $inputs['schor_text'];
            $SchorHorizontalText->language_id   = $inputs['language_id'];
			$SchorHorizontalText->status 			= $inputs['status'];
			$SchorHorizontalText->updated_at			= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($SchorHorizontalText); die;
    	    if(!$SchorHorizontalText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.schor_horizontal_text',$id)->with('success', 'Text Updated Successfully.'); 
    	}
    	return view('admin.schor_horizontal_text.create',$data);
    }

    public function remove(Request $request, $id=null, $text_id=null){
    	if(is_null($id) && is_null($text_id))
    	    return back()->with('danger','Something went wrong, Please try again.');

        $SchorHorizontalText = SchorHorizontalText::where(['id' => $text_id, 'concept_id' => $id])->first();
        if(@$SchorHorizontalText->id == "")
            return back()->with('danger','Aspiration text not found, Please try again.');

        $data['page_title'] = "Delete Aspiration Text";
        if(!$SchorHorizontalText->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.schor_horizontal_text',$id)->with('success', 'Text Deleted Successfully.'); 
    }
}

<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Batch;
use App\Models\Languages;
use App\Models\RatersInvite;
use App\Models\Questionnaire;
use App\Models\ParticipantsInvite;
use App\Models\ParticipantsReminderInvite;

class BatchController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	$data['page_title'] = "Batches";
    	$data['batches'] = Batch::get();
        $data['languages'] = Languages::where('status','Y')->get();
    	return view('admin.batches.manage',$data);
    }

    public function create(Request $request){
    	$data['page_title'] = "Create Batch";
        $data['participants_invites'] = ParticipantsInvite::where('status','Y')->get();
        $data['participants_reminder_invites'] = ParticipantsReminderInvite::where('status','Y')->get();
        $data['raters_invites'] = RatersInvite::where('status','Y')->get();
        $data['questionnaires'] = Questionnaire::where('status','Y')->get();

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['batch_name' => 'required','participants_invite_id' => 'required','participants_reminder_invite_id' => 'required','raters_invite_id' => 'required','questionnaire_id' => 'required','batch_deadline' => 'required','batch_norm' => 'required','invitation_method' => 'required','status' => 'required']);
    	    $Batch = new Batch();
			$Batch->batch_name = $inputs['batch_name'];
			$Batch->participants_invite_id 	= $inputs['participants_invite_id'];
            $Batch->participants_reminder_invite_id  = $inputs['participants_reminder_invite_id'];
            $Batch->raters_invite_id  = $inputs['raters_invite_id'];
            $Batch->questionnaire_id  = $inputs['questionnaire_id'];
            $Batch->batch_deadline  = date("Y-m-d",strtotime($inputs['batch_deadline']));
            $Batch->batch_norm  = $inputs['batch_norm'];
            $Batch->group_norm_name_id  = $inputs['group_norm_name_id'];
            $Batch->invitation_method  = $inputs['invitation_method'];
			$Batch->status 	= $inputs['status'];
			$Batch->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($Batch); die;
    	    if(!$Batch->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.batches')->with('success', 'Batch Added Successfully.'); 
    	}
    	return view('admin.batches.create',$data);
    }

    public function update(Request $request, $id=null){
        if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $Batch = Batch::find($id);
        if(@$Batch->id == "")
            return back()->with('danger','Batch not found, Please try again.');

        $data['participants_invites'] = ParticipantsInvite::where('status','Y')->get();
        $data['participants_reminder_invites'] = ParticipantsReminderInvite::where('status','Y')->get();
        $data['raters_invites'] = RatersInvite::where('status','Y')->get();
        $data['questionnaires'] = Questionnaire::where('status','Y')->get();

    	$data['page_title'] = "Edit Batch";
        $data['form_data'] = $Batch;

        $inputs = $request->all();
        if(@count($inputs) > 0){
            $this->validate($request,['batch_name' => 'required','participants_invite_id' => 'required','participants_reminder_invite_id' => 'required','raters_invite_id' => 'required','questionnaire_id' => 'required','batch_deadline' => 'required','batch_norm' => 'required','invitation_method' => 'required','status' => 'required']);
            $Batch->batch_name = $inputs['batch_name'];
            $Batch->participants_invite_id  = $inputs['participants_invite_id'];
            $Batch->participants_reminder_invite_id  = $inputs['participants_reminder_invite_id'];
            $Batch->raters_invite_id  = $inputs['raters_invite_id'];
            $Batch->questionnaire_id  = $inputs['questionnaire_id'];
            $Batch->batch_deadline  = date("Y-m-d",strtotime($inputs['batch_deadline']));
            $Batch->batch_norm  = $inputs['batch_norm'];
            $Batch->group_norm_name_id  = $inputs['group_norm_name_id'];
            $Batch->invitation_method  = $inputs['invitation_method'];
            $Batch->status  = $inputs['status'];
            $Batch->updated_at = date("Y-m-d H:i:s");
            // echo "<pre>"; print_r($AspirationQuestion); die;
            if(!$Batch->save())
                return back()->with('danger','Something went wrong, Please try again.');
            else
                return redirect()->route('admin.batches')->with('success', 'Batch Updated Successfully.'); 
        }
        return view('admin.batches.create',$data);
    }

    public function remove(Request $request, $id=null){
    	if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $Batch = Batch::find($id);
        if(@$Batch->id == "")
            return back()->with('danger','Batch not found, Please try again.');

        $data['page_title'] = "Delete Batch";
        if(!$Batch->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.batches')->with('success', 'Batch Deleted Successfully.'); 
        
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Questionnaire;

class QuestionnaireController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	$data['page_title'] = "Questionnaire";
    	$data['questionnaires'] = Questionnaire::get();
    	return view('admin.questionnaire.manage',$data);
    }

    private function getQuestionnaireSortCount(){
    	$count = 1;
    	$Questionnaire = Questionnaire::orderBy('sort','DESC')->first();
    	if(@$Questionnaire->id)
    		$count = ++$Questionnaire->sort;
    	return $count;
    }

    public function create(Request $request){
    	$data['page_title'] = "Create Questionnaire";
    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['questionnaire_name'=>'required','client_name'=>'required', 'created_at'=>'required', 'status'=>'required']);
    	    $Questionnaire = new Questionnaire();
			$Questionnaire->questionnaire_name 	= $inputs['questionnaire_name'];
			$Questionnaire->client_name 		= $inputs['client_name'];
			$Questionnaire->created_at			= $inputs['created_at'];
			$Questionnaire->status 				= $inputs['status'];
			$Questionnaire->sort 				= $this->getQuestionnaireSortCount();
    	    // echo "<pre>"; print_r($Questionnaire); die;
    	    if(!$Questionnaire->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.questionnaire')->with('success', 'Questionnaire Added Successfully.'); 
    	}
    	return view('admin.questionnaire.create',$data);
    }

    public function update(Request $request, $id=null){
        if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $Questionnaire = Questionnaire::find($id);
        if(@$Questionnaire->id == "")
            return back()->with('danger','Questionnaire not found, Please try again.');

    	$data['page_title'] = "Edit Questionnaire";
        $data['form_data'] = $Questionnaire;

        $inputs = $request->all();
        if(@count($inputs) > 0){
    		$this->validate($request,['questionnaire_name'=>'required','client_name'=>'required', 'created_at'=>'required', 'status'=>'required']);
			$Questionnaire->questionnaire_name 	= $inputs['questionnaire_name'];
			$Questionnaire->client_name 		= $inputs['client_name'];
			$Questionnaire->status 				= $inputs['status'];
			$Questionnaire->created_at			= $inputs['created_at'];
            $Questionnaire->updated_at = date("Y-m-d H:i:s");
            if(!$Questionnaire->save())
                return back()->with('danger','Something went wrong, Please try again.');
            else
                return redirect()->route('admin.questionnaire')->with('success', 'Questionnaire Updated Successfully.'); 
        }
        return view('admin.questionnaire.create',$data);
    }

    public function remove(Request $request, $id=null){
    	if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $Questionnaire = Questionnaire::find($id);
        if(@$Questionnaire->id == "")
            return back()->with('danger','Questionnaire not found, Please try again.');

        $data['page_title'] = "Delete Questionnaire";
        if(!$Questionnaire->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.questionnaire')->with('success', 'Questionnaire Deleted Successfully.'); 
        
    }
}

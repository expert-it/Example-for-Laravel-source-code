<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ParticipantsInvite;
use App\Models\ParticipantsInviteText;
use App\Models\Languages;

class ParticipantsInviteTextController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index($id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');
    	$data['page_title'] = "Invitation Text";
    	$data['ParticipantsInvite'] = ParticipantsInvite::find($id);
    	$data['id'] = $id;
    	$data['ParticipantsInviteTexts'] = ParticipantsInviteText::where('participants_invite_id',$id)->get();
    	return view('admin.participants_invite_text.manage',$data);
    }

    private function getParticipantsInviteTextSortCount(){
    	$count = 1;
    	$ParticipantsInvite = ParticipantsInviteText::orderBy('sort','DESC')->first();
    	if(@$ParticipantsInvite->id)
    		$count = ++$ParticipantsInvite->sort;
    	return $count;
    }

    public function create(Request $request, $id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');

    	$data['page_title'] = "Create Invitation Text";
    	$data['languages'] = Languages::where('status','Y')->get();
    	$data['ParticipantsInvite'] = ParticipantsInvite::find($id);

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['participants_invite_id'=>'required', 'invitation_subject'=>'required', 'invitation_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $ParticipantsInviteText = new ParticipantsInviteText();
    	    $ParticipantsInviteText->participants_invite_id	= $inputs['participants_invite_id'];
    	    $ParticipantsInviteText->invitation_subject		= $inputs['invitation_subject'];
    	    $ParticipantsInviteText->invitation_text 		= $inputs['invitation_text'];
    	    $ParticipantsInviteText->language_id 			= $inputs['language_id'];
			$ParticipantsInviteText->status 				= $inputs['status'];
			$ParticipantsInviteText->sort 					= $this->getParticipantsInviteTextSortCount();
			$ParticipantsInviteText->created_at				= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($ParticipantsInviteText); die;
    	    if(!$ParticipantsInviteText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.participants_invite_text',$id)->with('success', 'Invitation Text Added Successfully.'); 
    	}
    	return view('admin.participants_invite_text.create',$data);
    }

    public function update(Request $request, $id=null, $text_id=null){
        if(is_null($id) && is_null($text_id))
            return back()->with('danger','Something went wrong, Please try again.');
        
        $ParticipantsInvite = ParticipantsInvite::find($id);
        $ParticipantsInviteText = ParticipantsInviteText::where(['id' => $text_id, 'participants_invite_id' => $id])->first();
        if(@$ParticipantsInvite->id == "" || @$ParticipantsInviteText->id == "")
            return back()->with('danger','Invitation text not found, Please try again.');

    	$data['page_title'] = "Edit Invitation Text";
        $data['languages'] = Languages::where('status','Y')->get();
    	$data['ParticipantsInvite'] = $ParticipantsInvite;
    	$data['form_data'] = $ParticipantsInviteText;

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['participants_invite_id'=>'required', 'invitation_subject'=>'required', 'invitation_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $ParticipantsInviteText->participants_invite_id	= $inputs['participants_invite_id'];
    	    $ParticipantsInviteText->invitation_subject		= $inputs['invitation_subject'];
    	    $ParticipantsInviteText->invitation_text 		= $inputs['invitation_text'];
    	    $ParticipantsInviteText->language_id 			= $inputs['language_id'];
			$ParticipantsInviteText->status 				= $inputs['status'];
			$ParticipantsInviteText->updated_at				= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($ParticipantsInviteText); die;
    	    if(!$ParticipantsInviteText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.participants_invite_text',$id)->with('success', 'Invitation Text Updated Successfully.'); 
    	}
    	return view('admin.participants_invite_text.create',$data);
    }

    public function remove(Request $request, $id=null, $text_id=null){
    	if(is_null($id) && is_null($text_id))
    	    return back()->with('danger','Something went wrong, Please try again.');

        $ParticipantsInviteText = ParticipantsInviteText::where(['id' => $text_id, 'participants_invite_id' => $id])->first();
        if(@$ParticipantsInviteText->id == "")
            return back()->with('danger','Invitation text not found, Please try again.');

        $data['page_title'] = "Delete Invitation Text";
        if(!$ParticipantsInviteText->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.participants_invite_text',$id)->with('success', 'Invitation Text Deleted Successfully.'); 
    }
}
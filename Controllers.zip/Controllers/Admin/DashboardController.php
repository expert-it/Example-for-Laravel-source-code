<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Batch;
use App\Models\Questionnaire;
use App\Models\AspirationQuestion;


class DashboardController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	
    	$data['total_aspirations']=AspirationQuestion::where(['status'=>'Y'])->count();
    	$data['total_batches']=Batch::where(['status'=>'Y'])->count();
    	$data['total_questionnaires']=Questionnaire::where(['status'=>'Y'])->count();
    	$data['total_survay']=0;

    	return view('admin.dashboard',$data);
    }
}

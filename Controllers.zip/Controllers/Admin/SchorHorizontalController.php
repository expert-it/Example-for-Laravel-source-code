<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SchorHorizontal;

class SchorHorizontalController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	$data['page_title'] = "Schor Horizontal";
    	$data['schorHorizontal'] = SchorHorizontal::get();
    	return view('admin.schor_horizontal.manage',$data);
    }

    private function getSchorHorizontalSortCount(){
    	$count = 1;
    	$SchorHorizontal = SchorHorizontal::orderBy('sort','DESC')->first();
    	if(@$SchorHorizontal->id)
    		$count = ++$SchorHorizontal->sort;
    	return $count;
    }

    public function create(Request $request){
    	$data['page_title'] = "Create Schor Horizontal";
    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['horizontal_concept'=>'required', 'status'=>'required']);
    	    $SchorHorizontal = new SchorHorizontal();
			$SchorHorizontal->horizontal_concept = $inputs['horizontal_concept'];
			$SchorHorizontal->status 	= $inputs['status'];
			$SchorHorizontal->sort 		= $this->getSchorHorizontalSortCount();
			$SchorHorizontal->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($SchorHorizontal); die;
    	    if(!$SchorHorizontal->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.schor_horizontal')->with('success', 'Schor Horizontal Added Successfully.'); 
    	}
    	return view('admin.schor_horizontal.create',$data);
    }

    public function update(Request $request, $id=null){
        if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $SchorHorizontal = SchorHorizontal::find($id);
        if(@$SchorHorizontal->id == "")
            return back()->with('danger','Schor Horizontal not found, Please try again.');

    	$data['page_title'] = "Edit Schor Horizontal";
        $data['form_data'] = $SchorHorizontal;

        $inputs = $request->all();
        if(@count($inputs) > 0){
            $this->validate($request,['horizontal_concept'=>'required', 'status'=>'required']);
            $SchorHorizontal->horizontal_concept = $inputs['horizontal_concept'];
            $SchorHorizontal->status 	= $inputs['status'];
            $SchorHorizontal->updated_at = date("Y-m-d H:i:s");
            // echo "<pre>"; print_r($AspirationQuestion); die;
            if(!$SchorHorizontal->save())
                return back()->with('danger','Something went wrong, Please try again.');
            else
                return redirect()->route('admin.schor_horizontal')->with('success', 'Schor Horizontal Updated Successfully.'); 
        }
        // die("asd");
        return view('admin.schor_horizontal.create',$data);
    }

    public function remove(Request $request, $id=null){
    	if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $SchorHorizontal = SchorHorizontal::find($id);
        if(@$SchorHorizontal->id == "")
            return back()->with('danger','Schor Horizontal not found, Please try again.');

        $data['page_title'] = "Delete Schor Horizontal";
        if(!$SchorHorizontal->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.schor_horizontal')->with('success', 'Schor Horizontal Deleted Successfully.'); 
    }
}

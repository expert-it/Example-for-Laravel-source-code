<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Languages;
use App\Models\SchorVertical;
use App\Models\SchorVerticalText;

class SchorVerticalTextController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index($id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');
    	$data['page_title'] = "Schor Vertical Text";
    	$data['schorVertical'] = SchorVertical::find($id);
    	$data['id'] = $id;
    	$data['schorVerticalTexts'] = SchorVerticalText::where('concept_id',$id)->get();
    	return view('admin.schor_vertical_text.manage',$data);
    }

    private function getSchorVerticalTextSortCount(){
    	$count = 1;
    	$AspirationQuestion = SchorVerticalText::orderBy('sort','DESC')->first();
    	if(@$AspirationQuestion->id)
    		$count = ++$AspirationQuestion->sort;
    	return $count;
    }

    public function create(Request $request, $id=null){
    	if(is_null($id))
    	    return back()->with('danger','Something went wrong, Please try again.');

    	$data['page_title'] = "Create Schor Vertical Text";
    	$data['languages'] = Languages::where('status','Y')->get();
    	$data['schorVertical'] = SchorVertical::find($id);

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['schor_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
    	    $SchorVerticalText = new SchorVerticalText();
    	    $SchorVerticalText->concept_id	= $id;
    	    $SchorVerticalText->schor_text	= $inputs['schor_text'];
            $SchorVerticalText->language_id    = $inputs['language_id'];
			$SchorVerticalText->status 		= $inputs['status'];
			$SchorVerticalText->sort 			= $this->getSchorVerticalTextSortCount();
			$SchorVerticalText->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($SchorVerticalText); die;
    	    if(!$SchorVerticalText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.schor_vertical_text',$id)->with('success', 'Text Added Successfully.'); 
    	}
    	return view('admin.schor_vertical_text.create',$data);
    }

    public function update(Request $request, $id=null, $text_id=null){
        if(is_null($id) && is_null($text_id))
            return back()->with('danger','Something went wrong, Please try again.');
        
        $SchorVertical = SchorVertical::find($id);
        $SchorVerticalText = SchorVerticalText::where(['id' => $text_id, 'concept_id' => $id])->first();
        if(@$SchorVertical->id == "" || @$SchorVerticalText->id == "")
            return back()->with('danger','Schor Vertical Text not found, Please try again.');

    	$data['page_title'] = "Edit Schor Vertical Text";
        $data['languages'] = Languages::where('status','Y')->get();
    	$data['schorVertical'] = $SchorVertical;
    	$data['form_data'] = $SchorVerticalText;

    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['schor_text'=>'required', 'language_id'=>'required', 'status'=>'required']);
            $SchorVerticalText->concept_id    = $inputs['concept_id'];
            $SchorVerticalText->schor_text    = $inputs['schor_text'];
            $SchorVerticalText->language_id   = $inputs['language_id'];
			$SchorVerticalText->status 			= $inputs['status'];
			$SchorVerticalText->updated_at			= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($SchorVerticalText); die;
    	    if(!$SchorVerticalText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.schor_vertical_text',$id)->with('success', 'Text Updated Successfully.'); 
    	}
    	return view('admin.schor_vertical_text.create',$data);
    }

    public function remove(Request $request, $id=null, $text_id=null){
    	if(is_null($id) && is_null($text_id))
    	    return back()->with('danger','Something went wrong, Please try again.');

        $SchorVerticalText = SchorVerticalText::where(['id' => $text_id, 'concept_id' => $id])->first();
        if(@$SchorVerticalText->id == "")
            return back()->with('danger','Vertical text not found, Please try again.');

        $data['page_title'] = "Delete Vertical Text";
        if(!$SchorVerticalText->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.schor_vertical_text',$id)->with('success', 'Text Deleted Successfully.'); 
    }
}

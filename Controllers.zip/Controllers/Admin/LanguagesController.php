<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Languages;

class LanguagesController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	$data['page_title'] = "Languages";
    	$data['Languages'] = Languages::get();
    	return view('admin.languages.manage',$data);
    }

    private function getAspirationSortCount(){
    	$count = 1;
    	$Languages = Languages::orderBy('sort','DESC')->first();
    	if(@$Languages->id)
    		$count = ++$Languages->sort;
    	return $count;
    }

    public function create(Request $request){
    	$data['page_title'] = "Create Language";
    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['language'=>'required', 'status'=>'required']);
    	    $Languages = new Languages();
			$Languages->language 	= $inputs['language'];
			$Languages->file_name 	= strtolower($inputs['language']);
			$Languages->status 		= $inputs['status'];
			$Languages->sort 		= $this->getAspirationSortCount();
			$Languages->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($Languages); die;
    	    if(!$Languages->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.languages')->with('success', 'Language Added Successfully.'); 
    	}
    	return view('admin.languages.create',$data);
    }

    public function update(Request $request, $id=null){
        if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $Languages = Languages::find($id);
        if(@$Languages->id == "")
            return back()->with('danger','Language not found, Please try again.');

    	$data['page_title'] = "Edit Language";
        $data['form_data'] = $Languages;

        $inputs = $request->all();
        if(@count($inputs) > 0){
    		$this->validate($request,['language'=>'required', 'status'=>'required']);
			$Languages->language 	= $inputs['language'];
			$Languages->file_name 	= strtolower($inputs['language']);
			$Languages->status 		= $inputs['status'];
            $Languages->updated_at = date("Y-m-d H:i:s");
            // echo "<pre>"; print_r($Languages); die;
            if(!$Languages->save())
                return back()->with('danger','Something went wrong, Please try again.');
            else
                return redirect()->route('admin.languages')->with('success', 'Language Updated Successfully.'); 
        }
        return view('admin.languages.create',$data);
    }

    public function remove(Request $request, $id=null){
    	if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $Languages = Languages::find($id);
        if(@$Languages->id == "")
            return back()->with('danger','Language not found, Please try again.');

        $data['page_title'] = "Delete Language";
        if(!$Languages->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.languages')->with('success', 'Language Deleted Successfully.'); 
        
    }
}


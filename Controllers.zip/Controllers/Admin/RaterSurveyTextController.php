<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RaterSurveyText;
use App\Models\Languages;

class RaterSurveyTextController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	$data['page_title'] = "Survey Text";
    	$data['RaterSurveyTexts'] = RaterSurveyText::orderBy('type','ASC')->get();
    	return view('admin.raters_survey_text.manage',$data);
    }

    private function getAspirationSortCount($type){
    	$count = 1;
    	$RaterSurveyText = RaterSurveyText::where('type',$type)->orderBy('sort','DESC')->first();
    	if(@$RaterSurveyText->id)
    		$count = ++$RaterSurveyText->sort;
    	return $count;
    }

    public function create(Request $request){
    	$data['page_title'] = "Create Survey Text";
    	$inputs = $request->all();
    	$data['languages'] = Languages::where('status','Y')->get();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['text'=>'required', 'language_id'=>'required', 'type'=>'required', 'status'=>'required']);
    	    $RaterSurveyText = new RaterSurveyText();
			$RaterSurveyText->text 			= $inputs['text'];
			$RaterSurveyText->language_id 	= $inputs['language_id'];
			$RaterSurveyText->type 			= $inputs['type'];
			$RaterSurveyText->status 		= $inputs['status'];
			$RaterSurveyText->sort 			= $this->getAspirationSortCount($inputs['type']);
			$RaterSurveyText->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($RaterSurveyText); die;
    	    if(!$RaterSurveyText->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.raters_survey_text')->with('success', 'Survey Text Added Successfully.'); 
    	}
    	return view('admin.raters_survey_text.create',$data);
    }

    public function update(Request $request, $id=null){
        if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $RaterSurveyText = RaterSurveyText::find($id);
        if(@$RaterSurveyText->id == "")
            return back()->with('danger','Survey Text not found, Please try again.');

    	$data['page_title'] = "Edit Survey Text";
        $data['form_data'] = $RaterSurveyText;

        $inputs = $request->all();
        if(@count($inputs) > 0){
            $this->validate($request,['text'=>'required', 'language_id'=>'required', 'type'=>'required', 'status'=>'required']);
            $RaterSurveyText->text          = $inputs['text'];
            $RaterSurveyText->language_id   = $inputs['language_id'];
            $RaterSurveyText->type          = $inputs['type'];
            $RaterSurveyText->status        = $inputs['status'];
            $RaterSurveyText->updated_at = date("Y-m-d H:i:s");
            // echo "<pre>"; print_r($RaterSurveyText); die;
            if(!$RaterSurveyText->save())
                return back()->with('danger','Something went wrong, Please try again.');
            else
                return redirect()->route('admin.raters_survey_text')->with('success', 'Survey Text Updated Successfully.'); 
        }
        return view('admin.raters_survey_text.create',$data);
    }

    public function remove(Request $request, $id=null){
    	if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $RaterSurveyText = RaterSurveyText::find($id);
        if(@$RaterSurveyText->id == "")
            return back()->with('danger','Survey Text not found, Please try again.');

        $data['page_title'] = "Delete Survey Text";
        if(!$RaterSurveyText->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.raters_survey_text')->with('success', 'Survey Text Deleted Successfully.'); 
        
    }
}

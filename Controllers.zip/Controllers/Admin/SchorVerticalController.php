<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SchorVertical;

class SchorVerticalController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(){
    	$data['page_title'] = "Schor Vertical";
    	$data['schorVertical'] = SchorVertical::get();
    	return view('admin.schor_vertical.manage',$data);
    }

    private function getSchorVerticalSortCount(){
    	$count = 1;
    	$SchorVertical = SchorVertical::orderBy('sort','DESC')->first();
    	if(@$SchorVertical->id)
    		$count = ++$SchorVertical->sort;
    	return $count;
    }

    public function create(Request $request){
    	$data['page_title'] = "Create Schor Vertical";
    	$inputs = $request->all();
    	if(@count($inputs) > 0){
    		// echo "<pre>"; print_r($inputs); die;
    		$this->validate($request,['vertical_concept'=>'required', 'status'=>'required']);
    	    $SchorVertical = new SchorVertical();
			$SchorVertical->vertical_concept = $inputs['vertical_concept'];
			$SchorVertical->status 	= $inputs['status'];
			$SchorVertical->sort 		= $this->getSchorVerticalSortCount();
			$SchorVertical->created_at	= date("Y-m-d H:i:s");
    	    // echo "<pre>"; print_r($SchorVertical); die;
    	    if(!$SchorVertical->save())
    	        return back()->with('danger','Something went wrong, Please try again.');
    	    else
    	        return redirect()->route('admin.schor_vertical')->with('success', 'Schor Vertical Added Successfully.'); 
    	}
    	return view('admin.schor_vertical.create',$data);
    }

    public function update(Request $request, $id=null){
        if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $SchorVertical = SchorVertical::find($id);
        if(@$SchorVertical->id == "")
            return back()->with('danger','Schor Vertical not found, Please try again.');

    	$data['page_title'] = "Edit Schor Vertical";
        $data['form_data'] = $SchorVertical;

        $inputs = $request->all();
        if(@count($inputs) > 0){
            $this->validate($request,['vertical_concept'=>'required', 'status'=>'required']);
            $SchorVertical->vertical_concept = $inputs['vertical_concept'];
            $SchorVertical->status 	= $inputs['status'];
            $SchorVertical->updated_at = date("Y-m-d H:i:s");
            // echo "<pre>"; print_r($AspirationQuestion); die;
            if(!$SchorVertical->save())
                return back()->with('danger','Something went wrong, Please try again.');
            else
                return redirect()->route('admin.schor_vertical')->with('success', 'Schor Vertical Updated Successfully.'); 
        }
        // die("asd");
        return view('admin.schor_vertical.create',$data);
    }

    public function remove(Request $request, $id=null){
    	if(is_null($id))
            return back()->with('danger','Something went wrong, Please try again.');

        $SchorVertical = SchorVertical::find($id);
        if(@$SchorVertical->id == "")
            return back()->with('danger','Schor Vertical not found, Please try again.');

        $data['page_title'] = "Delete Schor Vertical";
        if(!$SchorVertical->delete())
            return back()->with('danger','Something went wrong, Please try again.');
        else
            return redirect()->route('admin.schor_vertical')->with('success', 'Schor Vertical Deleted Successfully.'); 
    }
}

<?php

namespace App\Http\Controllers\Utility;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Mail\SendMail;
use Mail;

use App\Models\Batch;
use App\Models\Languages;
use App\Models\Participants;
use App\Models\RatersInvite;
use App\Models\Questionnaire;
use App\Models\ParticipantsInvite;
use App\Models\ParticipantsReminderInvite;
use App\Models\ParticipantsInviteText;

class CommonController extends Controller
{
    public static function random_generator($digits){
        srand((double) microtime() * 10000000);
        $input = array("A", "B", "C", "D", "E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a", "b", "c", "d", "e","f","g","h","i","j","k","m","n","o","p","q","r","s","t","u","v","w","x","y","z");
        $random_generator="";
        for ($i=1; $i<=$digits; $i++) {
            if (rand(1,2) == 1) {
                $rand_index = array_rand($input);
                $random_generator .= $input[$rand_index];
            } else {
                $random_generator .= rand(2,9);
            }
        }
        return $random_generator;
    }

    public function mailParticipant(Request $request){
    	$inputs = $request->all();
    	$response = array();
    	if(@count($inputs) > 0){
    		$batch = Batch::find($inputs['id']);
    		if($batch){
    			// echo "<pre>"; print_r($batch); die;
    			$invitation_method = $batch->invitation_method;
    			$invitation_code = $batch->participants_invite_id;
    			$batch_deadline = $batch->batch_deadline;

    			$participants = Participants::where(['id' => $inputs['pid'],'batch_id' => $inputs['id']])->first();
    			// echo "<pre>"; print_r($participants); die;
    			if($participants){
    				if($invitation_method == 'username'){
    					$username = $participants->username;
    					$invitation_sent = 'Y';
    				}
    				else{
    					$username = $participants->email;
    					$invitation_sent = 'Y';
    				}
    				$language = $participants->language_id;
    				$passcode = $participants->password_text;
    				$invitation = ParticipantsInviteText::where(['participants_invite_id'=>$invitation_code, 'language_id' => $language])->first();
		    		if($invitation){
		    			$dd = "Username : ".$username;
			    		$uu = "Password : ".$passcode;
			    		if($invitation_method == 'email'){
                            $url = env('APP_URL').'/login/'.$inputs['type'];
                            $link ="Login Url : <a href='$url'>$url</a>";
                        }else{
                            $link ="Login Url : ".env('APP_URL').'/login/'.$inputs['type'];
                        }
			    		$batch_deadline = date("Y/m/d", strtotime($batch_deadline));
			    		$gg = "$dd\n$uu\n$link";

			    		$body = str_replace("{up}", $gg, $invitation->invitation_text);
			    		$body = str_replace("{due}", $batch_deadline, $body);

		                $from = env('MAIL_FROM_ADDRESS');
		                $fromName = env('MAIL_FROM_NAME');
						$to = $participants->email;
						$subject = $invitation->invitation_subject;
						$messages = $body;	
						if($invitation_method == 'email'){
                            $messages = nl2br($messages);
							$data=array("replyto"=>array($from,$fromName),"message"=>$messages);
							@Mail::to(@strtolower($to))->send(new SendMail($data, $subject));
							$message = ['subject' => $subject, 'messages' => $messages,'from' => $from, 'invitation_method' => $invitation_method];
							$response = array('message'=>'Mail sent successfully.','data'=>$message);
						}else{
							$message = ['subject' => $subject, 'messages' => $messages,'from' => $from, 'invitation_method' => $invitation_method];
							$response = array('message'=>'Mail content ready.','data'=>$message);
						}
		    		}else{
		    			$response = array('message'=>'Invitation text not added.','data'=>'');
		    		}
    			}else{
	    			$response = array('message'=>'Participant not found','data'=>'');
	    		}
    		}else{
    			$response = array('message'=>'Batch not found','data'=>'');
    		}
    	}
    	// echo "<pre>"; print_r($response); die;
    	return response()->json($response, 200);
    }
}

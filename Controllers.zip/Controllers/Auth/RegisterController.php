<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use App\Models\Admin;
use App\Models\Rater;
use App\Models\Participant;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;

use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class RegisterController extends Controller{

    use RegistersUsers;

    protected $redirectTo = RouteServiceProvider::HOME;

    public function __construct(){
        $this->middleware('guest');
        $this->middleware('guest:admin');
        $this->middleware('guest:rater');
        $this->middleware('guest:participant');
    }

    protected function validator(array $data){
        return Validator::make($data, [
            'username' => ['required', 'string', 'max:255', 'unique:users'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['required', 'string', 'max:255'],
        ]);
    }

    private function CreateUniqueId(){
        $uniq_id = md5(uniqid(rand(),true));
        // I am running, Till you get a unique key
        while(0){
            $user = User::where('uniq_id',$uniq_id)->count();
            if($user == 0)
                break;
            else
                $uniq_id = md5(uniqid(rand(),true));
        }
        return $uniq_id;
    }

    protected function create(array $data){
        // echo $this->CreateUniqueId(); die;
        return User::create([
            'uniq_id' => $this->CreateUniqueId(),
            'username' => $data['username'],
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email' => $data['email'],
            'role' => 2,
            'is_admin'=>"N",
            'is_active'=>"Y",
            'password' => Hash::make($data['password']),
        ]);
    }

    public function showAdminRegisterForm()
    {
       return view('auth.register', ['url' => 'admin']);
    }

    public function showRaterRegisterForm()
    {
       return view('auth.register', ['url' => 'rater']);
    }

    public function showParticipantRegisterForm()
    {
       return view('auth.register', ['url' => 'participant']);
    }

    protected function createAdmin(Request $request)
    {
        $this->validator($request->all())->validate();
        $input = [
                    'uniq_id' => $this->CreateUniqueId(),
                    'username' => $request['username'],
                    'first_name' => $request['first_name'],
                    'last_name' => $request['last_name'],
                    'email' => $request['email'],
                    'role' => 1,
                    'is_admin'=>"Y",
                    'is_active'=>"Y",
                    'password' => Hash::make($request['password']),
                ];
        // echo "<pre>"; print_r($input); die;
        User::create($input);
        return redirect()->intended('login/admin');
    }

    protected function createRater(Request $request)
    {
        $this->validator($request->all())->validate();
        $input = [
                    'uniq_id' => $this->CreateUniqueId(),
                    'username' => $request['username'],
                    'first_name' => $request['first_name'],
                    'last_name' => $request['last_name'],
                    'email' => $request['email'],
                    'role' => 3,
                    'is_admin'=>"N",
                    'is_active'=>"Y",
                    'password' => Hash::make($request['password']),
                ];
        // echo "<pre>"; print_r($input); die;
        User::create($input);
        return redirect()->intended('login/rater');
    }

    protected function createParticipant(Request $request)
    {
        $this->validator($request->all())->validate();
        $input = [
                    'uniq_id' => $this->CreateUniqueId(),
                    'username' => $request['username'],
                    'first_name' => $request['first_name'],
                    'last_name' => $request['last_name'],
                    'email' => $request['email'],
                    'role' => 2,
                    'is_admin'=>"N",
                    'is_active'=>"Y",
                    'password' => Hash::make($request['password']),
                ];
        // echo "<pre>"; print_r($input); die;
        User::create($input);
        return redirect()->intended('login/participant');
    }
}
<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

use Illuminate\Http\Request;
use Auth;

class LoginController extends Controller
{
    
    use AuthenticatesUsers;
    // protected $redirectTo = RouteServiceProvider::HOME;
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
        $this->middleware('guest:admin')->except('logout');
        $this->middleware('guest:rater')->except('logout');
        $this->middleware('guest:participant')->except('logout');
    }

    // ADMIN LOGIN START //
    public function showAdminLoginForm()
    {
        return view('auth.login', ['url' => 'admin']);
    }

    public function adminLogin(Request $request)
    {
        $this->validate($request, [
            'email'   => 'required|email', 'password' => 'required|min:6'
        ]);
        if (Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password], $request->get('remember'))){
            return redirect()->intended('/manage/admin');
        }
        return back()->withInput($request->only('email', 'remember'))->with('danger',"Please check incorrect Password or Email");
    }
    // ADMIN LOGIN END //

    // Participant LOGIN START //
    public function showParticipantLoginForm()
    {
       return view('auth.login', ['url' => 'participant']);
    }

    public function participantLogin(Request $request)
    {
       $this->validate($request, [
           'email'   => filter_var($request->email, FILTER_VALIDATE_EMAIL) ? 'required|email' : 'required',
           'password' => 'required|min:6'
       ]);

       if (Auth::guard('participant')->attempt([filter_var($request->email, FILTER_VALIDATE_EMAIL) ? 'email' : 'username' => $request->email, 'password' => $request->password], $request->get('remember')))
       {
           return redirect()->intended('/participant');
       }
       die('else');
       return back()->withInput($request->only('email', 'remember'))->with('danger',"Please check incorrect Password or Email");
    }
    // Participant LOGIN END //

    // RATER LOGIN START //
    public function showRaterLoginForm()
    {
       return view('auth.login', ['url' => 'rater']);
    }

    public function raterLogin(Request $request)
    {
       $this->validate($request, [
           'email'   => 'required|email',
           'password' => 'required|min:6'
       ]);

       if (Auth::guard('rater')->attempt(['email' => $request->email, 'password' => $request->password], $request->get('remember')))
       {
           return redirect()->intended('/rater');
       }
       die('else');
       return back()->withInput($request->only('email', 'remember'))->with('danger',"Please check incorrect Password or Email");
    }
    // RATER LOGIN END //
}
<?php

namespace App\Http\Controllers\Participant;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Utility\CommonController;
use Illuminate\Http\Request;
use App\Models\Languages;
use App\Models\RaterSurveyText;
use App\Models\RatersCredential;
use App\Models\Rater;
use App\Models\Survey;
use App\Models\RaterTypes;
use App\Models\RaterTypesText;
use Auth;
use DB;
use Session;

class SurveyController extends Controller
{
    
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if($this->CheckSurvey(Auth::guard('participant')->user()->id)){
                return back()->with('danger',"Survey Already Completed.");
            }else{
                return $next($request);
            }
        });
    }

    private function CheckSurvey($id=null)
    {
        $data = RatersCredential::whereIn('rater_key', Rater::select('raters_uniq')->where(['participant_id' => $id, 'rater_type' => 5])->get())->where(['status'=>'C','archived'=>'N'])->count();
        // echo "<pre>=>"; print_r($data); die;
        if($data > 0)
            return true;
        else
            return false;
    }

    private function getRaterSortCount()
    {
        $count = 1;
        $Rater = Rater::orderBy('sort','DESC')->first();
        if(@$Rater->id)
            $count = ++$Rater->sort;
        return $count;
    }
    
    private function getRatersCredentialSortCount()
    {
        $count = 1;
        $RatersCredential = RatersCredential::orderBy('sort','DESC')->first();
        if(@$RatersCredential->id)
            $count = ++$RatersCredential->sort;
        return $count;
    }

    private function get_previousdata($user_session=null){
        $mid = Survey::whereRaw('id = (select max(`id`) from surveys)')->where('session_key',$user_session)->first();
        if(@$mid->id != ""){
            $prevData = Survey::where(['session_key'=>$user_session,'id'=>$mid->id])->get();
        }else{
            $prevData = Survey::where(['session_key'=>$user_session,'id'=>1])->get();
        }
        return $prevData;
    }

    private function CheckRater($lang=1, $user_id=null, $rtype_id=null, $uniq_key=null, $participants_key=null){
        $rater = Rater::where(['participant_id'=>$user_id,'rater_type'=>$rtype_id])->first();
        // echo $user_id."<pre>=>"; print_r($rater); die;
        if(@count($rater) == 0){
            DB::beginTransaction();
            try
            {
                $raterModel = new Rater();
                $raterModel->participant_id =   $user_id;
                $raterModel->rater_type     =   $rtype_id;
                $raterModel->raters_uniq    =   str_replace(array('L', 'o', 'O', '1', '0', 'i', 'I'), array('U', 'a', '9', '8', 'p', 'k', 'm'), CommonController::random_generator(10));
                $raterModel->sort           =   $this->getRaterSortCount();
                $raterModel->status         =   "Y";
                $raterModel->created_at     =   date("Y-m-d H:i:s");
                $raterModel->save();
                
                $ratersCredentialModel = new RatersCredential();
                $ratersCredentialModel->rater_key   =   $raterModel->raters_uniq;  
                $ratersCredentialModel->session_key =   rand(0,1000).CommonController::random_generator(8);
                $ratersCredentialModel->language    =   $lang;
                $ratersCredentialModel->sort        =   $this->getRatersCredentialSortCount();
                $ratersCredentialModel->status      =   "Y";   
                $ratersCredentialModel->archived    =   "N";
                $ratersCredentialModel->created_at  =   $raterModel->created_at;
                $ratersCredentialModel->save();
                // echo "<pre>=>"; print_r($raterModel); print_r($ratersCredentialModel); die;
                $response=['success','welcome',$page=null,$lang];
            }
            catch(ValidationException $e)
            {
                DB::rollback();
                $response=['error',"Database error Please contact to admin",json_encode($e->getErrors())];
            }
            catch(\Exception $e)
            {
                DB::rollback();
                $response=['error',"Database error Please contact to admin",json_encode($e)];
            }
            DB::commit();
        }else{
            $participants = RatersCredential::where(['rater_key'=>$rater->raters_uniq, 'status'=>'Y', 'archived'=>'N'])->first();
            if(@count($participants) > 0){
                DB::beginTransaction();
                
                $user_session=$rater->session_key;
                $data = $this->get_previousdata($user_session);
                $data2 = RatersCredential::where('session_key',$user_session)->orderBy('id','ASC')->first();
                
                if(!empty($data2)){
                    if(!empty($data)){
                        $_SESSION[RATER_SESSION]=$user_session;
                        if($data2['language']!=0){
                             $lang=$data2['language'];
                        }
                        elseif(isset($_SESSION['language'])){
                            $lang=$_SESSION['language'];
                        }
                        else{
                            $lang=1;
                        }

                        if($data['page']!=0){
                             $page=$data['page'];
                        }
                        else{
                             $page=1;
                        }
                        $response=['success','welcome',$page,$lang];
                    }
                    else{
                         $_SESSION[RATER_SESSION]=$user_session;
                         if($data2['language']!=0){
                             $lang=$data2['language'];
                         }elseif(isset($_SESSION['language'])){
                          $lang=$_SESSION['language'];
                        }else{
                             $lang=1;
                         }
                        $response=['success','welcome',$page=null,$lang];
                    }
                }
                else{
                    $response=['success',"welcome page"];
                }   
            }else{
                $response=['danger',"You have already complete survey"];
            }
        }
        return $response;
    }

    public function index($lang=null, $page=null){
    	if(is_null($lang))
           $lang = Languages::orderBy('id','ASC')->first()->id;
        $rater_type = RaterTypes::where(['rater_type'=>'Self'])->first();
        
        $response = $this->CheckRater($lang, Auth::guard('participant')->user()->id, $rater_type->id, $rater_type->uniq_key, Session::get('_token'));         
        // echo "<pre>"; print_r($rater_type); die;
        
        $wecome_participant = RaterSurveyText::where(['language_id'=>$lang,'type'=>'welcome'])->first()->text;
        $gg=@Auth::guard('participant')->user()->first_name .' '. @Auth::guard('participant')->user()->last_name;
        $hh=str_replace("{survey by}", $gg, $wecome_participant);
        $ratername=RaterTypesText::where(['rater_id'=>$rater_type->id,'language_id'=>$lang])->first()->other_name;
        $welcome=str_replace("{type of raters}", $ratername, $hh);
        $data['welcome_text'] = $welcome;
        // echo "<pre>"; print_r($data['welcome_text']); die;
        // echo "<pre>"; print_r($data); die;
    	return view('participant.survey.welcome',$data);
    }
}